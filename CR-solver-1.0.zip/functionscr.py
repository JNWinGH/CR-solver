import numpy as np
from scipy.special import hankel1, hankel2
from math import pi
import cmath
import random
from numpy import pi, sqrt, log, abs as npabs
from math import isfinite
import matplotlib.pyplot as plt
from numpy import log10
from scipy import integrate
from mpmath import findroot  
from scipy.optimize import root_scalar
from scipy.optimize import newton
from multiprocessing import Pool, cpu_count
import time
import multiprocessing
from concurrent.futures import ProcessPoolExecutor
from math import isfinite

# ------------------------ Smoothed power spectrum ------------------------#

# functions for two peaks' locations

def x1stpk(beta):
    beta = np.asarray(beta)
    return 1.69 - 0.362*beta + 0.0326*beta**2

def x2ndpk(beta):
    beta = np.asarray(beta)
    return 2.14 - 0.145*beta - 0.406*beta**2 - 0.235*beta**3 - 0.0465*beta**4

# functions for two peaks' amplitudes

def f1(beta):
    beta = np.asarray(beta)
    return 1637.551 + 2376.283*beta + 1310.923*beta**2 + 323.051*beta**3 + 29.949*beta**4

def f2(beta):
    beta = np.asarray(beta)
    return 51.354 + 89.605*beta + 60.791*beta**2 + 18.264*beta**3 + 2.086*beta**4


# solve beta (half of second slow-roll parameter in CR phase)

def solvebeta(ratk, ratP):
    def fun(b):
        lhs = ratP
        rhs = (ratk * x1stpk(b) / x2ndpk(b))**(2*b + 6) * (f2(b) / f1(b))
        return lhs - rhs

    # Try a root near beta = -2.5
    res = root_scalar(fun, bracket=[-5, 0], method='brentq')
    if res.converged:
        return res.root
    else:
        try:
            return newton(fun, x0=-2.5)
        except Exception:
            raise RuntimeError("solvebeta failed to converge")

# solve NCR (duration of CR phase)
  
def solveNCR(ratk, ratP):
    beta = solvebeta(ratk, ratP)
    return log(ratk * x1stpk(beta) / x2ndpk(beta))


# breakpoints of the piecewise function for smoothed power spectrum
  
def kcut1(k1, taus):
    return k1 - pi/(2*taus)

def kcut2(k2, taue):
    return k2 - pi/(2*taue)

def kmid(beta, taue):
    return -np.sqrt((3 - 2*nu(beta)) / (2*nu(beta) - 1) * d0(beta)/d2(beta)) / taue

# nu = Abs[3/2 + beta]

def nu(beta):
    return abs(3/2 + beta)

# functions for the power spectrum around first peak, if beta < -3/2 

def Wd(beta):
    beta = np.asarray(beta)
    return 540 / (8*beta**2) * (-9 + 2*beta) * (-7 + 2*beta) * (-5 + 2*beta) * (9 - 40*beta**2 + 16*beta**4)**2

def W0(beta):
    beta = np.asarray(beta)
    return 120*beta**2 * (-9 + 2*beta) * (-7 + 2*beta) * (-5 + 2*beta) * (3 + 4*(-2 + beta)*beta)**2

def W2(beta):
    beta = np.asarray(beta)
    return 30 * (-9 + 2*beta) * (-7 + 2*beta) * (-5 + 2*beta) * (3 - 2*beta)**2 * (-1 + 2*beta) * (-1 - 2*beta + 4*beta**2)

def W4(beta):
    beta = np.asarray(beta)
    return 60*beta * (-9 + 2*beta) * (-7 + 2*beta) * (-5 + 2*beta) * (-3 + 2*beta) * (1 + 2*(-2 + beta)*beta)

def W6(beta):
    beta = np.asarray(beta)
    return 10*beta * (-9 + 2*beta) * (-7 + 2*beta) * (-3 + 2*beta) * (9 + 2*beta*(-7 + 2*beta))

def W8(beta):
    beta = np.asarray(beta)
    return 20*(-2 + beta)*beta * (-9 + 2*beta) * (5 + (-5 + beta)*beta)

def W10(beta):
    beta = np.asarray(beta)
    return (-3 + beta) * beta * (35 - 26*beta + 4*beta**2)

def W12(beta):
    beta = np.asarray(beta)
    return (648*beta - 762*beta**2 + 326*beta**3 - 60*beta**4 + 4*beta**5) / (3 * (-11 + 2*beta) * (-5 + 2*beta))

def W14(beta):
    beta = np.asarray(beta)
    return (1540*beta - 1453*beta**2 + 499*beta**3 - 74*beta**4 + 4*beta**5) / (
        21 * (-13 + 2*beta) * (-11 + 2*beta) * (-5 + 2*beta)
    )

# smoothed power spectrum around first peak 

def Psmo1stpk(k, beta, AIR, taus, taue):
    pref = AIR * (taue/taus)**(4*beta + 6) * (-k*taus)**4
    Wsum = (Wd(beta)**(-1)) * (
        W0(beta) + W2(beta)*(-k*taus)**2 + W4(beta)*(-k*taus)**4 +
        W6(beta)*(-k*taus)**6 + W8(beta)*(-k*taus)**8 +
        W10(beta)*(-k*taus)**10 + W12(beta)*(-k*taus)**12 +
        W14(beta)*(-k*taus)**14
    )
    return pref * Wsum


# functions for the power spectrum around second peak

def d0(beta):
    b = np.asarray(beta)
    return 1 + (4*b)/3 - (19*b**2)/72 - (103*b**3)/72 - (413*b**4)/288 - (61*b**5)/72 - (43*b**6)/144 - b**7/18 - b**8/288

def d2(beta):
    b = np.asarray(beta)
    return b/2880 * (-3072 + 196*b + 836*b**2 + 713*b**3 + 360*b**4 + 114*b**5 + 20*b**6 + b**7)

def d4(beta):
    b = np.asarray(beta)
    return b/50400 * (11520 - 364*b - 1404*b**2 - 1093*b**3 - 492*b**4 - 142*b**5 - 24*b**6 - b**7)

def d6(beta):
    b = np.asarray(beta)
    return b/(50400*27) * (-30720 + 580*b + 2116*b**2 + 1553*b**3 + 640*b**4 + 170*b**5 + 28*b**6 + b**7)

def d8(beta):
    b = np.asarray(beta)
    return b/52390800 * (67200 - 844*b - 2972*b**2 - 2093*b**3 - 804*b**4 - 198*b**5 - 32*b**6 - b**7)

def d10(beta):
    b = np.asarray(beta)
    return b/ (50400**2) * (-129024 + 1156*b + 3972*b**2 + 2713*b**3 + 984*b**4 + 226*b**5 + 36*b**6 + b**7)

def d12(beta):
    b = np.asarray(beta)
    return b/183891708000 * (225792 - 1516*b - 5116*b**2 - 3413*b**3 - 1180*b**4 - 254*b**5 - 40*b**6 - b**7)

# smoothed power spectrum on Ultraviolet limit

def AUV(beta, AIR, taus, taue):
    return AIR * (taue/taus)**(2*beta)

# smoothed power spectrum around second peak 

def Psmo2ndpk(k, beta, AIR, taus, taue):
    return AUV(beta, AIR, taus, taue) * (
        d0(beta) + d2(beta)*(-k*taue)**2 + d4(beta)*(-k*taue)**4 +
        d6(beta)*(-k*taue)**6 + d8(beta)*(-k*taue)**8 +
        d10(beta)*(-k*taue)**10 + d12(beta)*(-k*taue)**12
    )

# functions for power spectrum between first peak and second peak 

def Amid(beta, AIR, taus, taue):
    return AUV(beta, AIR, taus, taue) * (d0(beta) + d2(beta)*(-kmid(beta, taue)*taue)**2)

def delta(beta):
    b = beta
    if (-2 < b) and (b <= -3/2):
        return -0.63 - 1.44*(b + 3/2) - 0.43*(b + 3/2)**2
    elif (-3/2 < b) and (b < -1):
        return -0.63 + 2.5*(b + 3/2) - 2.9*(b + 3/2)**2
    else:
        return 0

# smoothed power spectrum between first peak and second peak

def Pmid(k, beta, AIR, taus, taue):
    return Amid(beta, AIR, taus, taue) * (k/kmid(beta, taue))**(3 - 2*nu(beta) + delta(beta))

#  smoothed power spectrum
  
def UnitStep(x):
    return (x >= 0).astype(float)

def Psmol4(k, beta, AIR, taus, taue, k1, k2):
    term1 = Psmo1stpk(k, beta, AIR, taus, taue)
    term2 = Pmid(k, beta, AIR, taus, taue)
    term3 = Psmo2ndpk(k, beta, AIR, taus, taue)
    u1 = UnitStep(kcut1(k1, taus) - k)
    u2 = UnitStep(k - kcut1(k1, taus)) * UnitStep(kmid(beta, taue) - k)
    u3 = UnitStep(k - kmid(beta, taue)) * UnitStep(kcut2(k2, taue) - k)
    u4 = UnitStep(k - kcut2(k2, taue))
    return term1*u1 + term2*u2 + term3*u3 + AUV(beta, AIR, taus, taue)*u4

def Psmol3(k, beta, AIR, taus, taue, k1, k2):
    term1 = Psmo1stpk(k, beta, AIR, taus, taue)
    term3 = Psmo2ndpk(k, beta, AIR, taus, taue)
    u1 = UnitStep(kcut1(k1, taus) - k)
    u3 = UnitStep(k - kcut1(k1, taus)) * UnitStep(kcut2(k2, taue) - k)
    u4 = UnitStep(k - kcut2(k2, taue))
    return term1*u1 + term3*u3 + AUV(beta, AIR, taus, taue)*u4

def Psmooth(k, beta, AIR, taus, taue, k1, k2):
    if kmid(beta, taue) < kcut1(k1, taus):
        return Psmol3(k, beta, AIR, taus, taue, k1, k2)
    else:
        return Psmol4(k, beta, AIR, taus, taue, k1, k2)

    
# ------------------------ Exact power spectrum ------------------------#
    
def C2(beta, k, taus):
    Nu = nu(beta)
    pref = np.pi * np.exp(-1j*k*taus) / (2**(7/2) * np.sqrt(k) * (-k*taus)**(3/2))
    term1 = 2*k*taus*(1 + 1j*k*taus) * hankel2(-1 + Nu, -k*taus)
    term2 = ((3 + 2*beta - 2*Nu)*(1 + 1j*k*taus) - 2*(k**2)*(taus**2)) * hankel2(Nu, -k*taus)
    return pref * (term1 - term2)

def D2(beta, k, taus):
    Nu = nu(beta)
    pref = - (np.pi * np.exp(-1j*k*taus)) / (2**(7/2) * np.sqrt(k) * (-k*taus)**(3/2))
    term1 = 2*k*taus*(1 + 1j*k*taus) * hankel1(-1 + Nu, -k*taus)
    term2 = ((3 + 2*beta - 2*Nu)*(1 + 1j*k*taus) - 2*(k**2)*(taus**2)) * hankel1(Nu, -k*taus)
    return pref * (term1 - term2)

def A(beta, k, taus, taue):
    Nu = nu(beta)
    return (np.exp(1j*k*taue) * np.sqrt(k)) / (2**(3/2) * (-k*taue)**(3/2)) * (
        C2(beta, k, taus) * ((2*k*taue*(1 - 1j*k*taue)) * hankel1(-1 + Nu, -k*taue)
                          + ((3 + 2*beta - 2*Nu)*(-1 + 1j*k*taue) + 2*k**2*(taue**2)) * hankel1(Nu, -k*taue)
        ) + D2(beta, k, taus) * ((2*k*taue*(1 - 1j*k*taue)) * hankel2(-1 + Nu, -k*taue)
                          + ((3 + 2*beta - 2*Nu)*(-1 + 1j*k*taue) + 2*k**2*(taue**2)) * hankel2(Nu, -k*taue)
        )
    )

def B(beta, k, taus, taue):
    Nu = nu(beta)
    return (np.exp(-1j*k*taue) * np.sqrt(k)) / (2**(3/2) * (-k*taue)**(3/2)) * (
        C2(beta, k, taus) * ((2*k*taue*(1 + 1j*k*taue)) * hankel1(-1 + Nu, -k*taue)
                          + ((3 + 2*beta - 2*Nu)*(-1 - 1j*k*taue) + 2*k**2*(taue**2)) * hankel1(Nu, -k*taue)
        ) + D2(beta, k, taus) * ((2*k*taue*(1 + 1j*k*taue)) * hankel2(-1 + Nu, -k*taue)
                          + ((3 + 2*beta - 2*Nu)*(-1 - 1j*k*taue) + 2*k**2*(taue**2)) * hankel2(Nu, -k*taue)
        )
    )

def Pexact(k, beta, AIR, taus, taue):
    Auv = AUV(beta, AIR, taus, taue)
    return Auv * abs(A(beta, k, taus, taue) - B(beta, k, taus, taue))**2

# --------------- Power spectrum used in the main program -------------------#
    
def PofkType(k, Type, beta_val, AIR, Tau_s, Tau_e, k1stpk, k2ndpk):
    # 大小写不敏感可用以下方式判断
    if str(Type).lower() == "exact":
        return Pexact(k, beta_val, AIR, Tau_s, Tau_e)
    elif str(Type).lower() == "smooth": 
        return Psmooth(k, beta_val, AIR, Tau_s, Tau_e, k1stpk, k2ndpk)
    else:
      raise ValueError('Type must be "exact" or "smooth"')
      return None
